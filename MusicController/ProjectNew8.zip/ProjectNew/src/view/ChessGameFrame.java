package view;

import Core.removablePostion;
import Enters.Enterframe;
import controller.GameController;
import model.ChessPiece;
import model.Chessboard;
import model.ChessboardPoint;
import model.Constant;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.awt.Robot;

import static Core.threeMatch.isMatched;
import static controller.GameController.shouldnext;
import static model.Chessboard.musicEffectAdjuster;
import static model.Chessboard.pausetime;

/**
 * 这个类表示游戏过程中的整个游戏界面，是一切的载体
 */
public class ChessGameFrame extends JFrame {
    JButton updatebutton = new JButton("Update");
    JButton swapconfirmbutton = new JButton("Confirm Swap");
    JButton nextStep = new JButton("Next Step");
    JButton tipsbutton = new JButton("Tips");
    boolean bomb=true;
    boolean knock=true;

    public  BackgroundPanel image=new BackgroundPanel();
    private final int WIDTH;
    private final int HEIGTH;

    private final int ONE_CHESS_SIZE;

    public GameController gameController;

    public ChessboardComponent chessboardComponent;
    public static boolean isauto=false;

    public JLabel statusLabel;//分数

    public JLabel nameLabel;//用户姓名

    public JLabel stepsLabel;//剩余步数

    public JLabel totalScore;

    public JLabel playerStage;

    public JLabel goal;

    public JLabel coinGoal;
    public JLabel Null;
    public Robot robot = new Robot();

    public static JLabel levelLabel;
    public Timer timer1 = new Timer(20, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // 定时器任务，每秒执行一次
            if (shouldnext(gameController.getModel().threematch)) {
                nextStep.setBackground(Color.GREEN);
            } else {
                nextStep.setBackground(UIManager.getColor("Button.background"));
            }
            if(!gameController.getModel().threematch.existChange()){
                updatebutton.setBackground(Color.GREEN);
            }else{
                updatebutton.setBackground(UIManager.getColor("Button.background"));
            }
        }
    });
    public Timer timer2 = new Timer(2000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // 定时器任务，每秒执行一次
            // nextStep.setLocation(HEIGTH, HEIGTH / 10 + 280);
            int x=HEIGTH+480,y=HEIGTH/10+460;
            if(isauto&&shouldnext(gameController.getModel().threematch)){
                robot.mouseMove(x,y);
                robot.mousePress(InputEvent.BUTTON1_MASK);
                robot.mouseRelease(InputEvent.BUTTON1_MASK);
            }
        }
    });

    public JLabel getCoinGoal() {
        return coinGoal;
    }

    public void setCoinGoal(JLabel coinGoal) {
        this.coinGoal = coinGoal;
    }

    public JLabel getGoal() {
        return goal;
    }

    public void setGoal(JLabel goal) {
        this.goal = goal;
    }

    public JLabel getPlayerStage() {
        return playerStage;
    }

    public void setPlayerStage(JLabel playerStage) {
        this.playerStage = playerStage;
    }

    public int count;
    //写一个增加菜单条的方法
    public void addMenubar(){
       JMenuBar menuBar=new JMenuBar();
        //自动模式
       JMenu automode=new JMenu("自动模式");

       JMenuItem autoon=new JMenuItem(new JMenuItem(new AbstractAction("自动") {
            @Override
            public void actionPerformed(ActionEvent e) {
                isauto=true;
            }
        }).getAction());
       JMenuItem autooff=new JMenuItem(new JMenuItem(new AbstractAction("手动") {
            @Override
            public void actionPerformed(ActionEvent e) {
                isauto=false;
            }
        }).getAction());
       automode.add(autoon);
       automode.add(autooff);
       menuBar.add(automode);

       //动画速度
       JMenu effectSpeed=new JMenu("动画速度");
       JMenuItem fast=new JMenuItem(new JMenuItem(new AbstractAction("较快") {
            @Override
            public void actionPerformed(ActionEvent e) {
                Chessboard.pausetime=500;
            }
       }).getAction());
       JMenuItem mid=new JMenuItem(new JMenuItem(new AbstractAction("默认") {
            @Override
            public void actionPerformed(ActionEvent e) {
                Chessboard.pausetime=800;
            }
       }).getAction());
       JMenuItem slow=new JMenuItem(new JMenuItem(new AbstractAction("较慢") {
            @Override
            public void actionPerformed(ActionEvent e) {
                Chessboard.pausetime=1300;
            }
       }).getAction());
        effectSpeed.add(fast);
        effectSpeed.add(mid);
        effectSpeed.add(slow);

        JMenu findRecord=new JMenu("查询记录");
        JMenuItem recording=new JMenuItem(new JMenuItem(new AbstractAction("游戏记录") {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 指定文件路径
                String filePath = "C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\Filepart\\recording.txt";
                // 创建File对象
                File file = new File(filePath);
                if (file.exists()) {
                    openFile(file);
                } else {
                    System.out.println("文件不存在: " + filePath);
                }
            }
            private static void openFile(File file) {
                // 获取Desktop实例
                Desktop desktop = Desktop.getDesktop();

                try {
                    // 使用默认关联的应用程序打开文件
                    desktop.open(file);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).getAction());
        findRecord.add(recording);

        JMenuItem bestrecording=new JMenuItem(new JMenuItem(new AbstractAction("最高纪录") {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 指定文件路径
                String filePath = "C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\Filepart\\bestrecord.txt";

                // 创建File对象
                File file = new File(filePath);

                // 检查文件是否存在
                if (file.exists()) {
                    openFile(file);
                } else {
                    System.out.println("文件不存在: " + filePath);
                }
            }

            private static void openFile(File file) {
                // 获取Desktop实例
                Desktop desktop = Desktop.getDesktop();

                try {
                    // 使用默认关联的应用程序打开文件
                    desktop.open(file);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).getAction());
        findRecord.add(bestrecording);

        JMenu setBackground=new JMenu("选择背景");
        JMenuItem open = new JMenuItem(new AbstractAction("打开"){
            JFileChooser chooser1 = new JFileChooser(".");
            @Override
            public void actionPerformed(ActionEvent e) {
                chooser1.showOpenDialog(null);
                File imageFile = chooser1.getSelectedFile();
                try {
                    String imagePath = imageFile.getAbsolutePath();//看路径
                    image.backgroundImage = new ImageIcon(imagePath).getImage();
                    image.repaint();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        setBackground.add(open);

        menuBar.add(effectSpeed);
        menuBar.add(setBackground);
        menuBar.add(findRecord);
        setJMenuBar(menuBar);
    }
    public JLabel getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(JLabel totalScore) {
        this.totalScore = totalScore;
    }

    public JLabel getNameLabel() {
        return nameLabel;
    }

    public void setNameLabel(JLabel nameLabel) {
        this.nameLabel = nameLabel;
    }

    public boolean existNulls(){
        for (int i = 0; i < gameController.getModel().threematch.chars.length; i++) {
            for (int j = 0; j <gameController.getModel().threematch.chars.length ; j++) {
                if(gameController.getModel().threematch.chars[i][j] == '0'){
                    return true;
                }
            }
        }
        return false;
    }
    public ChessGameFrame(int width, int height) throws AWTException {
        setTitle("玩家："+ Enterframe.name); //设置标题
        this.WIDTH = width;
        this.HEIGTH = height;
        this.ONE_CHESS_SIZE = (HEIGTH * 4 / 5) / 9;

        setSize(WIDTH, HEIGTH);
        setLocationRelativeTo(null); // Center the window.
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //设置程序关闭按键，如果点击右上方的叉就游戏全部关闭了
        setLayout(null);

        //在这里改背景
        setContentPane(image);
        setLayout(new BorderLayout());

        //尝试新添加一个背景
        addMenubar();
        addChessboard();
        addLabel();
        addUpdateButton();
        remainingSteps();
        addSwapConfirmButton();
        addNextStepButton();
        addTipsButton();
        //加了hammer后存在一些问题
        addKnock();addBomb();
        addlevelLabel();
        addNameLabel();
        totalScore();
        addStage();
        addGoal();
        if(Enterframe.modechoose == 1){
            addCoinGoal();
        }
        addNull();


        timer1.setRepeats(true);
        timer1.start();
        timer2.setRepeats(true);
        timer2.start();
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                timer1.stop();
            }
        });
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                timer2.stop();
            }
        });
    }

    public ChessboardComponent getChessboardComponent() {
        return chessboardComponent;
    }

    public void setChessboardComponent(ChessboardComponent chessboardComponent) {
        this.chessboardComponent = chessboardComponent;
    }

    public GameController getGameController() {
        return gameController;
    }

    public void setGameController(GameController gameController) {
        this.gameController = gameController;
    }

    /**
     * 在游戏面板中添加棋盘
     */
    private void addChessboard() {
        chessboardComponent = new ChessboardComponent(ONE_CHESS_SIZE);
        chessboardComponent.setLocation(HEIGTH / 5, HEIGTH / 10);
        add(chessboardComponent);
    }

    /**
     * 在游戏面板中添加标签
     */
    private void addNameLabel() {
        this.nameLabel = new JLabel("Name: " + Enterframe.name);
        nameLabel.setLocation(HEIGTH, HEIGTH / 100);
//        System.out.println("已执行");
        nameLabel.setSize(200, 60);
        nameLabel.setFont(new Font("Rockwell", Font.BOLD, 20));
        nameLabel.setForeground(Color.RED);
        add(nameLabel);
    }


    private void addLabel() {
        this.statusLabel = new JLabel("Currentscore: 0");
        statusLabel.setLocation(HEIGTH, HEIGTH / 10 +450);
        statusLabel.setSize(200, 60);
        statusLabel.setFont(new Font("Rockwell", Font.BOLD, 20));
        statusLabel.setForeground(Color.RED);
        add(statusLabel);
    }
    private void addlevelLabel() {
        this.levelLabel = new JLabel("level: " + Chessboard.level );
        levelLabel.setLocation(HEIGTH/2 , HEIGTH / 100);
        levelLabel.setSize(200, 60);
        levelLabel.setFont(new Font("Rockwell", Font.BOLD, 20));
        levelLabel.setForeground(Color.RED);
        add(levelLabel);
    }
    public void remainingSteps() {
        this.stepsLabel = new JLabel("Remaining steps: " + Chessboard.remainingSteps);
        stepsLabel.setLocation(HEIGTH, HEIGTH/10 + 500);
        stepsLabel.setSize(400, 60);
        stepsLabel.setFont(new Font("Rockwell", Font.BOLD, 20));
        stepsLabel.setForeground(Color.RED);
        add(stepsLabel);
    }
    public void totalScore() {
        this.totalScore = new JLabel("Totalscore: " + Chessboard.totalScore);
        totalScore.setLocation(HEIGTH, HEIGTH/100 + 60 );
        totalScore.setSize(400, 60);
        totalScore.setFont(new Font("Rockwell", Font.BOLD, 20));
        totalScore.setForeground(Color.RED);
        add(totalScore);
    }
    public void addStage() {
        if(Chessboard.level == 1){
            this.playerStage = new JLabel("Stage: " + Chessboard.playerStage%3);
        }
        if(Chessboard.level == 2){
            this.playerStage = new JLabel("Stage: " + Chessboard.playerStage%3);
        }
        if(Chessboard.level == 3){
            this.playerStage = new JLabel("Stage: " + (Chessboard.playerStage%3));
        }
        this.playerStage = new JLabel("Stage: " + Chessboard.playerStage);
        playerStage.setLocation(HEIGTH, HEIGTH/100 + 140);
        playerStage.setSize(400, 60);
        playerStage.setFont(new Font("Rockwell", Font.BOLD, 20));
        playerStage.setForeground(Color.RED);
        add(playerStage);
    }
    public void addGoal() {
        this.goal = new JLabel("Goal: " + Chessboard.levelScore);
       goal.setLocation(HEIGTH, HEIGTH/100 + 100);
       goal.setSize(400, 60);
        goal.setFont(new Font("Rockwell", Font.BOLD, 20));
        goal.setForeground(Color.RED);
        add(goal);
    }
    public void addCoinGoal() {
        this.coinGoal = new JLabel("CoinGoal: " + Chessboard.coinGoal);
       coinGoal.setLocation(HEIGTH +120, HEIGTH/100 + 100);
        coinGoal.setSize(400, 60);
        coinGoal.setFont(new Font("Rockwell", Font.BOLD, 20));
        coinGoal.setForeground(Color.RED);
        add(coinGoal);
    }

    public void addNull() {
        this.Null = new JLabel("" );
        Null.setLocation(HEIGTH, HEIGTH/10 + 100 );
        Null.setSize(400, 60);
        Null.setFont(new Font("Rockwell", Font.BOLD, 20));
        Null.setForeground(Color.RED);
        add(Null);
    }


    public JLabel getStatusLabel() {
        return statusLabel;
    }

    public void setStatusLabel(JLabel statusLabel) {
        this.statusLabel = statusLabel;
    }

    /**
     * 在游戏面板中增加一个按钮，如果按下的话就会显示Hello, world!
     */

    private void addUpdateButton() {
        updatebutton.addActionListener(e -> {
           if(existNulls()){
               JOptionPane.showMessageDialog(null,"You need to click next step!","Operation hint",JOptionPane.WARNING_MESSAGE);
                   return;
           }
            if(count < 3){
               gameController.upDate(Enterframe.modechoose);
               count++;
               gameController.getModel().drawAgain();
           }else{
               JOptionPane.showMessageDialog(null,"You have used the tips three times!","",JOptionPane.INFORMATION_MESSAGE);
            }
        });
        updatebutton.setLocation(HEIGTH, HEIGTH / 10 + 120);
        updatebutton.setSize(200, 60);
        updatebutton.setFont(new Font("Rockwell", Font.BOLD, 20));
        add(updatebutton);
    }

    private void addSwapConfirmButton() {
        swapconfirmbutton.addActionListener((e) -> chessboardComponent.swapChess());
        swapconfirmbutton.setLocation(HEIGTH, HEIGTH / 10 + 200);
        swapconfirmbutton.setSize(200, 60);
        swapconfirmbutton.setFont(new Font("Rockwell", Font.BOLD, 20));
        add(swapconfirmbutton);
    }

    private void addNextStepButton() {
        nextStep.addActionListener((e) -> chessboardComponent.nextStep());
        nextStep.setLocation(HEIGTH, HEIGTH / 10 + 280);
        nextStep.setSize(200, 60);
        nextStep.setFont(new Font("Rockwell", Font.BOLD, 20));
        add(nextStep);
    }
    public void addKnock(){
        JButton knockbutton=new JButton("Knock");//把hammer图片icon放进去
        knockbutton.setLocation(HEIGTH, HEIGTH / 10 + 440);
        knockbutton.setSize(100, 30);
        knockbutton .setFont(new Font("Rockwell", Font.BOLD, 20));
        add(knockbutton);
        knockbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //找到唯一的
                //没有和两个都报错
                //消除，移动
                if(knock){
                    var point1 = (ChessComponent) gameController.view.getGridComponentAt(gameController.selectedPoint).getComponent(0);
                    var point2 = (ChessComponent) gameController.view.getGridComponentAt(gameController.selectedPoint).getComponent(0);

                    if(gameController.selectedPoint!=null&&gameController.selectedPoint2==null||gameController.selectedPoint2!=null&&gameController.selectedPoint==null){
                        int x=0,y=0;
                        if(gameController.selectedPoint!=null){
                            x=gameController.selectedPoint.getRow();y=gameController.selectedPoint.getCol();
                        }else{
                            x=gameController.selectedPoint2.getRow();y=gameController.selectedPoint2.getCol();
                        }
                        if(gameController.getModel().threematch.chars[x][y]=='-'||gameController.getModel().threematch.chars[x][y]=='+'){
                            JOptionPane.showMessageDialog(null,"This piece can't be removed!","Operation hint",JOptionPane.WARNING_MESSAGE);
                        }else{
                            knock=false;
                            gameController.getModel().threematch.chars[x][y]='k';
                            gameController.paintChesspiece();
                            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\锤子音效1.wav");
                            System.out.println("zhixingl ");

                            gameController.getModel().threematch.chars[x][y]='0';
                            gameController.getModel().threematch.drop();
                            gameController.PauseDrawChesspiece();

                            gameController.getModel().threematch.fillEmpty();
                            gameController.PauseDrawChesspiece();
                            boolean flag=true;
                            while (flag){
                                flag=isMatched(gameController.model.threematch.chars,gameController.model.threematch.state,gameController.row, gameController.col);
                                gameController.getModel().threematch.caculateSum();
                                gameController.getModel().threematch.drop();
                                gameController.PauseDrawChesspiece();
                                gameController.getModel().threematch.fillEmpty();
                                gameController.PauseDrawChesspiece();
                            }
                        }
                    }else{
                        JOptionPane.showMessageDialog(null,"Choose one piece to remove!","Operation hint",JOptionPane.WARNING_MESSAGE);
                    }
                    gameController.selectedPoint=null;
                    gameController.selectedPoint2=null;

                    point1.setSelected(false);
                    point1.repaint();
                    point2.setSelected(false);
                    point2.repaint();
                }else{
                    JOptionPane.showMessageDialog(null,"Knock has been used!","Operation hint",JOptionPane.WARNING_MESSAGE);
                }

            }
        });
    }
    public static boolean isInboundary(int row,int col,int x,int y){
        if(x>=0&&x<row&&y>=0&&y<=col)return true;
        return false;
    }
    public void addBomb(){
        JButton bombbutton=new JButton("Bomb");//把hammer图片icon放进去
        bombbutton.setLocation(HEIGTH+100, HEIGTH / 10 + 440);
        bombbutton.setSize(100, 30);
        bombbutton .setFont(new Font("Rockwell", Font.BOLD, 20));
        add(bombbutton);
        bombbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //找到唯一的
                //没有和两个都报错
                //消除，移动
                if(bomb){
                    var point1 = (ChessComponent) gameController.view.getGridComponentAt(gameController.selectedPoint).getComponent(0);
                    var point2 = (ChessComponent) gameController.view.getGridComponentAt(gameController.selectedPoint).getComponent(0);

                    if(gameController.selectedPoint!=null&&gameController.selectedPoint2==null||gameController.selectedPoint2!=null&&gameController.selectedPoint==null){
                        int x=0,y=0;
                        if(gameController.selectedPoint!=null){
                            x=gameController.selectedPoint.getRow();y=gameController.selectedPoint.getCol();
                        }else{
                            x=gameController.selectedPoint2.getRow();y=gameController.selectedPoint2.getCol();
                        }
                        if(gameController.getModel().threematch.chars[x][y]=='-'||gameController.getModel().threematch.chars[x][y]=='+'){
                            JOptionPane.showMessageDialog(null,"This piece can't be bombed!","Operation hint",JOptionPane.WARNING_MESSAGE);
                        }else{
                            if(isInboundary(gameController.row, gameController.col,x-1,y)&&gameController.getModel().threematch.chars[x-1][y]!='-')gameController.getModel().threematch.chars[x-1][y]='0';
                            if(isInboundary(gameController.row, gameController.col,x,y-1)&&gameController.getModel().threematch.chars[x][y-1]!='-')gameController.getModel().threematch.chars[x][y-1]='0';
                            if(isInboundary(gameController.row, gameController.col,x+1,y)&&gameController.getModel().threematch.chars[x+1][y]!='-')gameController.getModel().threematch.chars[x+1][y]='0';
                            if(isInboundary(gameController.row, gameController.col,x,y+1)&&gameController.getModel().threematch.chars[x][y+1]!='-')gameController.getModel().threematch.chars[x][y+1]='0';

                            bomb=false;
                            gameController.getModel().threematch.chars[x][y]='b';//可以加一张图片
                            gameController.paintChesspiece();
                            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\爆炸.wav");

                            gameController.getModel().threematch.chars[x][y]='0';
                            gameController.getModel().threematch.drop();
                            gameController.PauseDrawChesspiece();

                            gameController.getModel().threematch.fillEmpty();
                            gameController.PauseDrawChesspiece();
                            boolean flag=true;
                            while (flag){
                                flag=isMatched(gameController.model.threematch.chars,gameController.model.threematch.state,gameController.row, gameController.col);
                                gameController.getModel().threematch.caculateSum();
                                gameController.getModel().threematch.drop();
                                gameController.PauseDrawChesspiece();

                                gameController.getModel().threematch.fillEmpty();
                                gameController.PauseDrawChesspiece();
                            }
                        }
                    }else{
                        JOptionPane.showMessageDialog(null,"Choose one piece to bomb!","Operation hint",JOptionPane.WARNING_MESSAGE);
                    }
                    gameController.selectedPoint=null;
                    gameController.selectedPoint2=null;

                    point1.setSelected(false);
                    point1.repaint();
                    point2.setSelected(false);
                    point2.repaint();
                }else{
                    JOptionPane.showMessageDialog(null,"Bomb has been used!","Operation hint",JOptionPane.WARNING_MESSAGE);
                }
            }
        });
    }
    public void PauseDrawChesspiece(){
        Timer timer = new Timer(pausetime, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < gameController.model.threematch.chars.length; i++) {
                    for (int j = 0; j <  gameController.model.threematch.chars.length; j++) {
                        gameController.model.getGrid()[i][j].getPiece().setColor(Constant.getColorMap().get(ChessPiece.nameDecide(gameController.model.threematch.chars[i][j])));
                        gameController.model.getGrid()[i][j].getPiece().setName(ChessPiece.nameDecide(gameController.model.threematch.chars[i][j]));
                        gameController.model.getGrid()[i][j].getPiece().chessComponent.revalidate();
                        gameController.model.getGrid()[i][j].getPiece().chessComponent.repaint();
                    }
                }
            }
        });

        timer.setRepeats(false);
        timer.start();
    }//设置了一个延迟画图的方法
    private void addTipsButton() {
        tipsbutton.setLocation(HEIGTH, HEIGTH / 10 + 360);
        tipsbutton.setSize(200, 60);
        tipsbutton.setFont(new Font("Rockwell", Font.BOLD, 20));
        add(tipsbutton);

        tipsbutton.addActionListener(e -> {
           if(gameController.getModel().threematch.existChange()){
               int num=gameController.getModel().threematch.removablePostionList.size();
               Random random=new Random();
               int n=random.nextInt(num);
               removablePostion tipposition=gameController.getModel().threematch.removablePostionList.get(n);
               int x1=tipposition.x,y1=tipposition.y;
               int dr=0,dc=0;
               if(tipposition.d=='r'){
                   dc=1;dr=0;
               }else{
                   dr=1;dc=0;
               }
               int x2=x1+dr,y2=y1+dc;

               gameController.selectedPoint=new ChessboardPoint(x1,y1);
               gameController.selectedPoint2=new ChessboardPoint(x2,y2);

               var point1 = (ChessComponent) gameController.view.getGridComponentAt(gameController.selectedPoint).getComponent(0);
               var point2 = (ChessComponent) gameController.view.getGridComponentAt(gameController.selectedPoint2).getComponent(0);
               point1.setSelected(true);
               point1.repaint();
               point2.setSelected(true);
               point2.repaint();
           }
        });
    }
    public JLabel getStepsLabel() {
        return stepsLabel;
    }

    public void setStepsLabel(JLabel stepsLabel) {
        this.stepsLabel = stepsLabel;
    }
    public JLabel getLevelLabel() {
        return levelLabel;
    }
    public void setLevelLabel(JLabel levelLabel) {
        this.levelLabel = levelLabel;
    }
}
class BackgroundPanel extends JPanel {
    public Image backgroundImage;
    public BackgroundPanel(){
        setBackgroundImage("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\Enters\\Enterbackground.png");
    }

    public void setBackgroundImage(String imagePath) {
        this.backgroundImage = new ImageIcon(imagePath).getImage();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);

        }else{
            System.out.println("没画出来");
        }
    }

}


