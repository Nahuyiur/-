package Enters;
import Core.Mode0;
import Core.Mode1;
import Core.Mode2;
import MusicController.BGMadjuster;
import MusicController.MusicEffectAdjuster;
import MusicController.VolumeAdjuster;
import controller.GameController;
import model.ChessPiece;
import model.Chessboard;
import Core.threeMatch;
import model.Constant;
import view.ChessGameFrame;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Filepart.ReadAndOverwrite;
public class Enterframe extends JFrame {
    JFrame frame=new JFrame("疯狂三消！！！");
    Container c=frame.getContentPane();
    JMenuBar menuBar=new JMenuBar();
    File background0= new File("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\Enters\\Enterpicture.png");
    BufferedImage image;
    ArrayList<String> gamelist;
    public static String name;
    public int row=8;
    public int col=8;
    public int sleeptime= 800;
    public static int modechoose = 0;


    JPanel drawArea = new MyCanvas();
    {
        try {
            image = ImageIO.read(background0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    class MyCanvas extends JPanel{
        @Override
        public void paint(Graphics g) {
            if (image!=null){
                g.drawImage(image,0,0,this);
            }
        }//draw here and can be seen
    }

    //设置菜单内容
    public void addMenu(){
        JMenu setMenu=new JMenu("设置");
        JMenu findRecord=new JMenu("查询记录");
        JMenu setBackground=new JMenu("选择背景");//设置背景的菜单
        JMenu effectSpeed=new JMenu("动画速度");

        //模式选取的菜单栏
        JMenu modeMenu=new JMenu("选择模式");
        JButton mode0 = new JButton(new AbstractAction("经典模式"){
            @Override
            public void actionPerformed(ActionEvent e) {
                modeMenu.setText("当前模式：经典模式");
                modechoose=0;
            }
        });
        JButton mode1 = new JButton(new AbstractAction("金币模式"){
            @Override
            public void actionPerformed(ActionEvent e) {
                modeMenu.setText("当前模式：金币模式");
                modechoose=1;
            }
        });
        JButton mode2= new JButton(new AbstractAction("障碍模式"){
            @Override
            public void actionPerformed(ActionEvent e) {
                modeMenu.setText("当前模式：障碍模式");
                modechoose=2;
            }
        });
        modeMenu.add(mode0);
        modeMenu.add(mode1);
        modeMenu.add(mode2);

        //难度选取以及设置
        JMenu levelmenu = new JMenu("选择关卡");
        JButton  level1= new JButton("Level 1");
        JButton level2 = new JButton("Level 2");
        JButton level3 = new JButton("Level 3");
        levelmenu.add(level1);
        levelmenu.add(level2);
        levelmenu.add(level3);
        MouseListener mouseListener0 = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Chessboard.level = 1;
                Chessboard.remainingSteps = 20;
                Chessboard.levelScore = 10;
                Chessboard.playerStage = 1;
                Chessboard.totalScore = 0;
                Chessboard.coinGoal = 1;
                levelmenu.setText("当前关卡：Level 1");
            }
        };

        MouseListener mouseListener1 = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Chessboard.level = 2;
                Chessboard.remainingSteps = 10;
                Chessboard.levelScore = 80;
                Chessboard.playerStage = 4;
                Chessboard.totalScore = 0;
                Chessboard.coinGoal = 1;
                levelmenu.setText("当前关卡：Level 2");
            }
        };
        MouseListener mouseListener2 = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Chessboard.level = 3;
                Chessboard.remainingSteps = 4;
                Chessboard.levelScore = 100;
                Chessboard.playerStage = 7;
                Chessboard.totalScore = 0;
                Chessboard.coinGoal = 1;
                levelmenu.setText("当前关卡：Level 3");

            }
        };
        level1.addMouseListener(mouseListener0);
        level2.addMouseListener(mouseListener1);
        level3.addMouseListener(mouseListener2);

        JMenuItem fast=new JMenuItem(new JMenuItem(new AbstractAction("较快") {
            @Override
            public void actionPerformed(ActionEvent e) {
                sleeptime=500;
            }
        }).getAction());
        JMenuItem mid=new JMenuItem(new JMenuItem(new AbstractAction("默认") {
            @Override
            public void actionPerformed(ActionEvent e) {
                sleeptime=800;
            }
        }).getAction());
        JMenuItem slow=new JMenuItem(new JMenuItem(new AbstractAction("较慢") {
            @Override
            public void actionPerformed(ActionEvent e) {
                sleeptime=1300;
            }
        }).getAction());
        effectSpeed.add(fast);
        effectSpeed.add(mid);
        effectSpeed.add(slow);

        //关于音乐的参数设置
        JMenuItem music=new JMenuItem(new JMenuItem(new AbstractAction("背景音乐") {
            @Override
            public void actionPerformed(ActionEvent e) {
                new BGMadjuster();
            }
        }).getAction());
        JMenuItem musicEffect=new JMenuItem(new JMenuItem(new AbstractAction("音乐效果") {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MusicEffectAdjuster();
            }
        }).getAction());
        JMenuItem volume=new JMenuItem(new JMenuItem(new AbstractAction("音量") {
            @Override
            public void actionPerformed(ActionEvent e) {
                new VolumeAdjuster();
            }
        }).getAction());

        setMenu.add(music);
        setMenu.add(musicEffect);
        setMenu.add(volume);


        //调记录
        JMenuItem recording=new JMenuItem(new JMenuItem(new AbstractAction("游戏记录") {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 指定文件路径
                String filePath = "C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\Filepart\\recording.txt";
                // 创建File对象
                File file = new File(filePath);
                if (file.exists()) {
                    openFile(file);
                } else {
                    System.out.println("文件不存在: " + filePath);
                }
            }
            private static void openFile(File file) {
                // 获取Desktop实例
                Desktop desktop = Desktop.getDesktop();

                try {
                    // 使用默认关联的应用程序打开文件
                    desktop.open(file);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).getAction());
        findRecord.add(recording);

        JMenuItem bestrecording=new JMenuItem(new JMenuItem(new AbstractAction("最高纪录") {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 指定文件路径
                String filePath = "C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\Filepart\\bestrecord.txt";

                // 创建File对象
                File file = new File(filePath);

                // 检查文件是否存在
                if (file.exists()) {
                    openFile(file);
                } else {
                    System.out.println("文件不存在: " + filePath);
                }
            }

            private static void openFile(File file) {
                // 获取Desktop实例
                Desktop desktop = Desktop.getDesktop();

                try {
                    // 使用默认关联的应用程序打开文件
                    desktop.open(file);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).getAction());
        findRecord.add(bestrecording);


        //选择背景的菜单设置
        JMenuItem open = new JMenuItem(new AbstractAction("打开"){
            JFileChooser chooser1 = new JFileChooser(".");
            @Override
            public void actionPerformed(ActionEvent e) {
                chooser1.showOpenDialog(frame);
                File imageFile = chooser1.getSelectedFile();
                try {
                    image = ImageIO.read(imageFile);
                    String imagePath = imageFile.getAbsolutePath();//看路径
                    drawArea.repaint();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        });
        setBackground.add(open);

        menuBar.add(setMenu);
        menuBar.add(effectSpeed);
        menuBar.add(setBackground);
        menuBar.add(findRecord);
        menuBar.add(levelmenu);
        menuBar.add(modeMenu);

        frame.setJMenuBar(menuBar);

        //初始状态是经典模式
        mode0.setSelected(true);
        modeMenu.setText("当前模式：经典模式");
        //初始状态下设置成level1，属性全部改成level1的
        level1.setSelected(true);
        Chessboard.level = 1;
        Chessboard.remainingSteps = 5;
        Chessboard.levelScore = 100;
        Chessboard.playerStage = 1;
        Chessboard.totalScore = 0;
        Chessboard.coinGoal = 1;
        levelmenu.setText("当前关卡：Level 1");

    }

    //设置按钮

    // 判断文件是否是txt文件
    public static boolean isTxtFile(File file) {
        String fileName = file.getName();
        int lastDotIndex = fileName.lastIndexOf(".");
        if (lastDotIndex != -1) {
            String fileExtension = fileName.substring(lastDotIndex + 1);
            return fileExtension.equalsIgnoreCase("txt");
        }
        return false;
    }
    public static boolean isSizeRight(List<String> list){
        if(list.size()!=10)return false;
        for (int i = 2; i < list.size() ; i++) {
            String str=(String) list.get(i);
            if(str.length()!=8)return false;
        }
        return true;
    }
    public static boolean isCharsRight(List<String> list){
        for (int i = 2; i < list.size() ; i++) {
            String str=(String) list.get(i);
            for (int j = 0; j < str.length(); j++) {
                if(!charJudge(str.charAt(j)))return false;
            }
        }
        return true;
    }
    public static boolean charJudge(char c){
        switch (c){
            case '1':
                return true;
            case '2':
                return true;
            case '3':
                return true;
            case '4':
                return true;
            case '+':
                return true;
            case '-':
                return true;
            default:
                return false;
        }
    }
    public void addButtons(){//只与下方的三个按键有关
        JPanel bottom=new JPanel();
        JButton startButton=new JButton("开始游戏");
        JButton closeButton=new JButton("关闭游戏");
        JButton readButton=new JButton("读取存档");
        MouseListener reader=new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e)  {
                super.mouseClicked(e);
                // 判断文件是否是txt文件
                JFileChooser chooser2 = new JFileChooser(".");
                int result=chooser2.showOpenDialog(frame);
                if(result==JFileChooser.APPROVE_OPTION) {
                    File gameRecordFile = chooser2.getSelectedFile();
                    if (!isTxtFile(gameRecordFile)) {
                        JOptionPane.showMessageDialog(null, "请选择一个txt文件！", "错误编码：101", JOptionPane.ERROR_MESSAGE);
                    } else {
                        String gameRecordFileAbsolutePath = gameRecordFile.getAbsolutePath();//看路径
                        ReadAndOverwrite readAndOverwrite = new ReadAndOverwrite();
                        gamelist = (ArrayList<String>) readAndOverwrite.readFileToList(gameRecordFileAbsolutePath);
                        if(!isSizeRight(gamelist)) {
                            JOptionPane.showMessageDialog(null, "请选择8*8大小的棋盘！", "错误编码：102", JOptionPane.ERROR_MESSAGE);
                        }else{
                            if (!isCharsRight(gamelist)) {
                                JOptionPane.showMessageDialog(null, "存在非指定的棋子", "错误编码：103", JOptionPane.ERROR_MESSAGE);
                            }else{
                                JOptionPane.showMessageDialog(null,"读取成功！\n继续你的冒险吧,"+name+"!");
                                //这里的棋盘就应该是符合规定的
                                threeMatch cdthreematch=new threeMatch(gameRecordFileAbsolutePath,row,col);
                                Chessboard cdchessboard=new Chessboard(cdthreematch);
                                cdchessboard.threematch=cdthreematch;

                                //存档的模式信息都没改
                                //存档现在有问题
                                ChessGameFrame mainFrame = null;
                                try {
                                    mainFrame = new ChessGameFrame(1100, 810);
                                } catch (AWTException ex) {
                                    throw new RuntimeException(ex);
                                }
                                //什么都没有，棋子没有
                                GameController gameController = new GameController(mainFrame.getChessboardComponent(), cdchessboard);
                                mainFrame.setGameController(gameController);
                                //尝试重新画
                                //需要你解决
                                /*for (int i = 0; i < gameController.model.threematch.chars.length; i++) {
                                    for (int j = 0; j <  gameController.model.threematch.chars.length; j++) {
                                        gameController.model.getGrid()[i][j].getPiece().setName(ChessPiece.nameDecide(cdthreematch.chars[i][j]));
                                        gameController.model.getGrid()[i][j].getPiece().chessComponent.revalidate();
                                        gameController.model.getGrid()[i][j].getPiece().chessComponent.repaint();
                                    }
                                }

*/
                                gameController.setStepsLabel(mainFrame.getStepsLabel());
                                gameController.setStatusLabel(mainFrame.getStatusLabel());
                                gameController.setNameLabel(mainFrame.getNameLabel());
                                gameController.setTotalScore(mainFrame.getTotalScore());
                                gameController.setPlayerStage(mainFrame.getPlayerStage());
                                gameController.setCoinGoal(mainFrame.getCoinGoal());
                                Chessboard.totalScore = 0;

                                mainFrame.setVisible(true);
                                frame.setVisible(false);
                            }
                        }
                        //属性中gamelist是array list<String>，用文件读入方法写的
                    }
                } else if (result == JFileChooser.CANCEL_OPTION) {
                    chooser2.cancelSelection();
                }
            }
        };
        MouseListener closeenter=new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.setVisible(false);
            }
        };
        MouseListener startenter=new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                name= JOptionPane.showInputDialog("你好啊，冒险者!\n为自己取一个帅气的名字吧：");
                try {
                    while(name.length() == 0) {
                        name = JOptionPane.showInputDialog("名字会作为你冒险的记录\n为自己取一个帅气的名字吧：");
                    }
                }catch (Exception j){
                }
                if(name==null)return;
                JOptionPane.showMessageDialog(null,"很好，"+name+"\n开启你传奇的冒险吧！");

                ChessGameFrame mainFrame = null;
                try {
                    mainFrame = new ChessGameFrame(1100, 810);
                } catch (AWTException ex) {
                    throw new RuntimeException(ex);
                }
                Chessboard cb=new Chessboard();

                if(modechoose==0)cb=new Chessboard(new Mode0(8,8));
                if(modechoose==1)cb=new Chessboard(new Mode1(8,8));
                if(modechoose==2)cb=new Chessboard(new Mode2(8,8));
                cb.pausetime =getSleeptime();

                GameController gameController = new GameController(mainFrame.getChessboardComponent(), cb);
                mainFrame.setGameController(gameController);

                gameController.setStatusLabel(mainFrame.getStatusLabel());
                gameController.setStepsLabel(mainFrame.getStepsLabel());
                gameController.setNameLabel(mainFrame.getNameLabel());
                gameController.setTotalScore(mainFrame.getTotalScore());
                gameController.setPlayerStage(mainFrame.getPlayerStage());
                gameController.setCoinGoal(mainFrame.getCoinGoal());
                Chessboard.totalScore = 0;
                mainFrame.setVisible(true);
                frame.setVisible(false);
            }
        };
        startButton.addMouseListener(startenter);
        closeButton.addMouseListener(closeenter);
        readButton.addMouseListener(reader);

        bottom.add(startButton);
        bottom.add(closeButton);
        bottom.add(readButton);

        c.add(bottom,BorderLayout.SOUTH);
    }
    public void initial(){
        addMenu();

        frame.setSize(1100,810);
        drawArea.setPreferredSize(new Dimension(1000,800));

        c.add(drawArea,BorderLayout.CENTER);
        addButtons();

        //显示frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }
    public int getSleeptime(){
        return sleeptime;
    }
}
