package controller;

import Core.Mode1;
import Core.Mode2;
import Enters.Enterframe;
import listener.GameListener;
import model.ChessPiece;
import model.Constant;
import model.Chessboard;
import model.ChessboardPoint;
import Core.threeMatch;
import view.CellComponent;
import view.ChessComponent;
import view.ChessGameFrame;
import view.ChessboardComponent;

import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static model.Chessboard.musicEffectAdjuster;
import static model.Chessboard.pausetime;

/**
 * Controller is the connection between model and view,
 * when a Controller receive a request from a view, the Controller
 * analyzes and then hands over to the model for processing
 * [in this demo the request methods are onPlayerClickCell() and
 * onPlayerClickChessPiece()]
 */
public class GameController implements GameListener {
    public Chessboard model;//model是chessboard类型
    public ChessboardComponent view;

    // Record whether there is a selected piece before
    public ChessboardPoint selectedPoint;
    public ChessboardPoint selectedPoint2;
    private JLabel statusLabel;
    public int row=Constant.CHESSBOARD_ROW_SIZE.getNum();
    public int col=Constant.CHESSBOARD_COL_SIZE.getNum();

    private JLabel stepsLabel;

    private JLabel nameLabel;

    private JLabel totalScore;

    private JLabel playerStage;

    private JLabel coinGoal;

    public JLabel getCoinGoal() {
        return coinGoal;
    }

    public void setCoinGoal(JLabel coinGoal) {
        this.coinGoal = coinGoal;
    }

    public JLabel getPlayerStage() {
        return playerStage;
    }

    public void setPlayerStage(JLabel playerStage) {
        this.playerStage = playerStage;
    }

    public JLabel getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(JLabel totalScore) {
        this.totalScore = totalScore;
    }

    public JLabel getNameLabel() {
        return nameLabel;
    }

    public void setNameLabel(JLabel nameLabel) {
        this.nameLabel = nameLabel;
    }

    public JLabel getStepsLabel() {
        return stepsLabel;
    }

    public void setStepsLabel(JLabel stepsLabel) {
        this.stepsLabel = stepsLabel;
    }

    public JLabel getStatusLabel() {
        return statusLabel;
    }

    public void setStatusLabel(JLabel statusLabel) {
        this.statusLabel = statusLabel;
    }

    public GameController(ChessboardComponent view, Chessboard model) {
        this.view = view;
        this.model = model;

        view.registerController(this);
        view.initiateChessComponent(model);
        view.repaint();
    }
    @Override
    public void onPlayerClickCell(ChessboardPoint point, CellComponent component) {
    }

    @Override
    public void onPlayerSwapChess() {
        if(Chessboard.countSteps == 1){
            JOptionPane.showMessageDialog(null,"You need to click next step!","Operation hint",JOptionPane.WARNING_MESSAGE);
            return;
        }
        else{
            if(existNull()){
                JOptionPane.showMessageDialog(null,"You need to click next step!","Operation hint",JOptionPane.WARNING_MESSAGE);
                return;
            }else{
                if(threeMatch.isMatched(model.threematch.chars,model.threematch.state,model.threematch.row,model.threematch.col)){
                    JOptionPane.showMessageDialog(null,"You need to click next step!","Operation hint",JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
        }

        if((Enterframe.modechoose == 0 || Enterframe.modechoose == 2) && Chessboard.remainingSteps == 0 && model.threematch.score < Chessboard.levelScore){
            model.threematch.fillEmpty();
                paintChesspiece();
                JOptionPane.showMessageDialog(null,"You failed!\nTry again!","Game result",JOptionPane.WARNING_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\失败.wav");
        }

        if(Enterframe.modechoose == 1 && Chessboard.remainingSteps == 0 && (model.threematch.score < Chessboard.levelScore || Mode1.coin < Chessboard.coinGoal)){
            model.threematch.fillEmpty();
            paintChesspiece();
            JOptionPane.showMessageDialog(null,"You failed!\nTry again!","Game result",JOptionPane.WARNING_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\失败.wav");
        }


        if(Enterframe.modechoose == 0 || Enterframe.modechoose == 2 ){
           judgeWin();
       }else{
            judgeWin1();
        }


       if(selectedPoint!=null&&selectedPoint2!=null&&Chessboard.remainingSteps!= 0){
            model.swapChessPiece(selectedPoint,selectedPoint2);
            this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
        }else{
            JOptionPane.showMessageDialog(null,"Please choose two chesspieces to swap!","Operation hint",JOptionPane.WARNING_MESSAGE);
        }
        setNullClick();
    }

    @Override
    //添加一些必要的操作
    public void onPlayerNextStep() {
        if(!existNull() && !threeMatch.isMatched(model.threematch.chars,model.threematch.state,model.threematch.row,model.threematch.col)){
            Chessboard.countSteps = 0;
            System.out.println(Chessboard.countSteps);
        }

        if(!existNull() && !threeMatch.isMatched(model.threematch.chars,model.threematch.state,model.threematch.row,model.threematch.col)){
            JOptionPane.showMessageDialog(null,"You need to swap first!","Operation hint",JOptionPane.WARNING_MESSAGE);}

        if((Enterframe.modechoose == 0 || Enterframe.modechoose == 2) && Chessboard.remainingSteps == 0 && model.threematch.score < Chessboard.levelScore){
            model.threematch.fillEmpty();
            paintChesspiece();
            JOptionPane.showMessageDialog(null,"You failed!\nTry again!","Game result",JOptionPane.WARNING_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\失败.wav");
        }

        if(Enterframe.modechoose == 1 && Chessboard.remainingSteps == 0 && (model.threematch.score < Chessboard.levelScore || Mode1.coin < Chessboard.coinGoal)){
            model.threematch.fillEmpty();
            paintChesspiece();
            JOptionPane.showMessageDialog(null,"You failed!\nTry again!","Game result",JOptionPane.WARNING_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\失败.wav");
        }
        if(threeMatch.isMatched(model.threematch.chars,model.threematch.state,model.threematch.row,model.threematch.col)) {
            model.threematch.caculateSum();
            this.statusLabel.setText("Score:" + model.threematch.score);
            this.totalScore.setText("Totalscore: " + Chessboard.totalScore );
            System.out.println(Chessboard.totalScore);
            model.threematch.drop();
            paintChesspiece();
            model.threematch.fillEmpty();
            model.PauseDraw();
        }
        if(model.sum == 1){
            model.threematch.drop();
            this.statusLabel.setText("Score:" + model.threematch.score);
            this.totalScore.setText("Totalscore: " + Chessboard.totalScore);
            paintChesspiece();
            model.sum++;
            if(Enterframe.modechoose == 0 || Enterframe.modechoose == 2 ){
                judgeWin();
            }else{
                judgeWin1();
            }

        } else if(model.sum == 2 ){
            model.threematch.fillEmpty();
            model.PauseDraw();
            model.sum = 0;
            if(Enterframe.modechoose == 0 || Enterframe.modechoose == 2 ){
                judgeWin();
            }else{
                judgeWin1();
            }

        }
        if(!existNull() && !threeMatch.isMatched(model.threematch.chars,model.threematch.state,model.threematch.row,model.threematch.col)){
            Chessboard.countSteps = 0;
        }
    }
    public static boolean shouldnext(threeMatch threematch){
        if(!existNull(threematch) && !threeMatch.isMatched(threematch.chars,threematch.state,threematch.row,threematch.col)){
            return false;
        }
        return true;
    }
    public static boolean existNull(threeMatch threematch){
        for (int i = 0; i < threematch.row; i++) {
            for (int j = 0; j < threematch.col; j++) {
                if(threematch.chars[i][j]=='0')return true;
            }
        }
        return false;
    }
    public void setNullClick(){
        var point1 = (ChessComponent) view.getGridComponentAt(selectedPoint).getComponent(0);
        var point2 = (ChessComponent) view.getGridComponentAt(selectedPoint2).getComponent(0);
        point1.setSelected(false);
        point1.repaint();
        point2.setSelected(false);
        point2.repaint();

        selectedPoint=null;
        selectedPoint2=null;
    }

    // click a cell with a chess
    @Override
    public void onPlayerClickChessPiece(ChessboardPoint point, ChessComponent component) {
        //选定并且画出已选棋子的圈
        if (selectedPoint2 != null) {
            var distance2point1 = Math.abs(selectedPoint.getCol() - point.getCol()) + Math.abs(selectedPoint.getRow() - point.getRow());
            var distance2point2 = Math.abs(selectedPoint2.getCol() - point.getCol()) + Math.abs(selectedPoint2.getRow() - point.getRow());
            var point1 = (ChessComponent) view.getGridComponentAt(selectedPoint).getComponent(0);
            var point2 = (ChessComponent) view.getGridComponentAt(selectedPoint2).getComponent(0);
            if (distance2point1 == 0 && point1 != null) {
                point1.setSelected(false);
                point1.repaint();
                selectedPoint = selectedPoint2;
                selectedPoint2 = null;
            } else if (distance2point2 == 0 && point2 != null) {
                point2.setSelected(false);
                point2.repaint();
                selectedPoint2 = null;
            } else if (distance2point1 == 1 && point2 != null) {
                point2.setSelected(false);
                point2.repaint();
                selectedPoint2 = point;
                component.setSelected(true);
                component.repaint();
            } else if (distance2point2 == 1 && point1 != null) {
                point1.setSelected(false);
                point1.repaint();
                selectedPoint = selectedPoint2;
                selectedPoint2 = point;
                component.setSelected(true);
                component.repaint();
            }
            return;
        }
        if (selectedPoint == null) {
            selectedPoint = point;
            component.setSelected(true);
            component.repaint();
            return;
        }

        var distance2point1 = Math.abs(selectedPoint.getCol() - point.getCol()) + Math.abs(selectedPoint.getRow() - point.getRow());

        if (distance2point1 == 0) {
            selectedPoint = null;
            component.setSelected(false);
            component.repaint();
            return;
        }

        if (distance2point1 == 1) {
            selectedPoint2 = point;
            component.setSelected(true);
            component.repaint();
        } else {
            selectedPoint2 = null;

            var grid = (ChessComponent) view.getGridComponentAt(selectedPoint).getComponent(0);
            if (grid == null) return;
            grid.setSelected(false);
            grid.repaint();

            selectedPoint = point;
            component.setSelected(true);
            component.repaint();
        }


    }
    //public boolean result(int steps,int score,int levelScore)
    public void upDate(int mode){
        threeMatch updatethreematch=new threeMatch(row,col);
        if(mode==1)updatethreematch=new Mode1(row,col);
        if(mode==2)updatethreematch=new Mode2(row,col);
        for (int i = 0; i <row ; i++) {
            for (int j = 0; j < col; j++) {
                model.threematch.chars[i][j]=updatethreematch.chars[i][j];
                model.threematch.state[i][j]=true;
                model.sum = 0;
            }
        }
    }




    public Chessboard getModel() {
        return model;
    }

    public void setModel(Chessboard model) {
        this.model = model;
    }



    public boolean existNull(){
        for (int i = 0; i < model.threematch.chars.length; i++) {
            for (int j = 0; j <model.threematch.chars[1].length ; j++) {
                if(model.threematch.chars[i][j] == '0'){
                    return true;
                }
            }
        }
        return false;

    }
    public void judgeWin(){
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 1){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                paintChesspiece();
                Chessboard.level = 2;
                Chessboard.levelScore = 80;
                Chessboard.remainingSteps = 6;
                model.threematch.score = 0;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);
            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 2){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
               paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                paintChesspiece();
                Chessboard.level = 3;
                Chessboard.levelScore =100;
                Chessboard.remainingSteps = 4;
                model.threematch.score = 0;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);

            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 3){
            if(existNull()){
                model.threematch.fillEmpty();
               paintChesspiece();
            }

            JOptionPane.showMessageDialog(null,"YOU have completed all challenges! ","",JOptionPane.INFORMATION_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 4){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
               paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                paintChesspiece();
                Chessboard.level = 3;
                Chessboard.levelScore =1000;
                Chessboard.remainingSteps = 4;
                model.threematch.score = 0;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);

            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 5){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
               paintChesspiece();
                Chessboard.level = 3;
                Chessboard.levelScore =1000;
                Chessboard.remainingSteps = 4;
                model.threematch.score = 0;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);

            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 6){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            JOptionPane.showMessageDialog(null,"YOU have completed all challenges! ","",JOptionPane.INFORMATION_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
        } if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&(Chessboard.playerStage == 7 || Chessboard.playerStage == 8)){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
               paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                paintChesspiece();
                Chessboard.level = 3;
                Chessboard.levelScore =1000;
                Chessboard.remainingSteps = 4;
                model.threematch.score = 0;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);

            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }

        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 9){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            JOptionPane.showMessageDialog(null,"YOU have completed all challenges! ","",JOptionPane.INFORMATION_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
        }
    }
    public void judgeWin1(){
        System.out.println("woshiyongle");
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore && Chessboard.playerStage == 1 && Mode1.coin >= Chessboard.coinGoal){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                model.threematch.fillEmpty();
//                for (int i = 0; i < model.threematch.chars.length ; i++) {
//                    for (int j = 0; j < model.threematch.chars.length; j++) {
//                        System.out.println(model.threematch.chars[i][j]);
//                    }
//                }
                paintChesspiece();
                Chessboard.level = 2;
                Chessboard.levelScore = 80;
                Chessboard.remainingSteps = 6;
                Chessboard.coinGoal = 2;
                model.threematch.score = 0;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);
            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 2&&Mode1.coin >= Chessboard.coinGoal){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                model.threematch.fillEmpty();
                paintChesspiece();
                Chessboard.level = 3;
                Chessboard.levelScore =100;
                Chessboard.remainingSteps = 4;
                model.threematch.score = 0;
                Chessboard.coinGoal = 2;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);

            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 3 &&Mode1.coin >=Chessboard.coinGoal){
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }

            JOptionPane.showMessageDialog(null,"YOU have completed all challenges! ","",JOptionPane.INFORMATION_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 4&&Mode1.coin >= Chessboard.coinGoal){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                model.threematch.fillEmpty();
                paintChesspiece();
                Chessboard.level = 3;
                Chessboard.levelScore =1000;
                Chessboard.remainingSteps = 4;
                model.threematch.score = 0;
                Chessboard.coinGoal = 2;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);

            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 5 &&Mode1.coin >= Chessboard.coinGoal){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                model.threematch.fillEmpty();
                paintChesspiece();
                Chessboard.level = 3;
                Chessboard.levelScore =1000;
                Chessboard.remainingSteps = 4;
                model.threematch.score = 0;
                Chessboard.coinGoal = 2;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);

            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 6&&Mode1.coin >Chessboard.coinGoal){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            JOptionPane.showMessageDialog(null,"YOU have completed all challenges! ","",JOptionPane.INFORMATION_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
        } if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&(Chessboard.playerStage == 7 || Chessboard.playerStage == 8) &&Mode1.coin  >= Chessboard.coinGoal){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
            int result = JOptionPane.showOptionDialog(
                    null,
                    "You Succeeded!\nDo you want to enter the next level?",
                    "Game result",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new Object[]{"确定", "取消"},
                    "确定");
            //这里需要对话框分支判断;
            if (result == JOptionPane.YES_OPTION) {
                upDate(Enterframe.modechoose);
                model.threematch.fillEmpty();
                paintChesspiece();
                Chessboard.level = 3;
                Chessboard.levelScore =1000;
                Chessboard.remainingSteps = 4;
                model.threematch.score = 0;
                Chessboard.coinGoal = 2;
                this.statusLabel.setText("Score: 0");
                this.playerStage.setText("Stage: " + Chessboard.playerStage%3);
                this.stepsLabel.setText("Remaining steps: " + Chessboard.remainingSteps);
                ChessGameFrame.levelLabel.setText("Level: " + Chessboard.level);

            } else {
                JOptionPane.showMessageDialog(null,"Thanks for playing! ","",JOptionPane.INFORMATION_MESSAGE);
            }

        }
        if(Chessboard.remainingSteps == 0 && model.threematch.score >= Chessboard.levelScore&&Chessboard.playerStage == 9 &&Mode1.coin >= Chessboard.coinGoal){
            Chessboard.playerStage++;
            if(existNull()){
                model.threematch.fillEmpty();
                paintChesspiece();
            }
            JOptionPane.showMessageDialog(null,"YOU have completed all challenges! ","",JOptionPane.INFORMATION_MESSAGE);
            musicEffectAdjuster.playMusic("C:\\Users\\ruiyu\\IdeaProjects\\ProjectNew\\src\\MusicController\\胜利.wav");
        }
    }




    public void paintChesspiece(){
        for (int i = 0; i < model.threematch.chars.length; i++) {
            for (int j = 0; j <  model.threematch.chars.length; j++) {
                model.getGrid()[i][j].getPiece().setColor(Constant.getColorMap().get(ChessPiece.nameDecide(model.threematch.chars[i][j])));
                model.getGrid()[i][j].getPiece().setName(ChessPiece.nameDecide(model.threematch.chars[i][j]));
                model.getGrid()[i][j].getPiece().chessComponent.revalidate();
                model.getGrid()[i][j].getPiece().chessComponent.repaint();
            }
        }
    }
    public void PauseDrawChesspiece(){
        Timer timer = new Timer(pausetime, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < model.threematch.chars.length; i++) {
                    for (int j = 0; j <  model.threematch.chars.length; j++) {
                        model.getGrid()[i][j].getPiece().setColor(Constant.getColorMap().get(ChessPiece.nameDecide(model.threematch.chars[i][j])));
                        model.getGrid()[i][j].getPiece().setName(ChessPiece.nameDecide(model.threematch.chars[i][j]));
                        model.getGrid()[i][j].getPiece().chessComponent.revalidate();
                        model.getGrid()[i][j].getPiece().chessComponent.repaint();
                    }
                }
            }
        });

        timer.setRepeats(false);
        timer.start();
    }//设置了一个延迟画图的方法

}






