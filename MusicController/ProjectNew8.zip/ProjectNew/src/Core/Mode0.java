package Core;

public class Mode0 extends threeMatch{
    public Mode0(int row,int col){
        super(row,col);
    }
    //最原始的模式
    public Mode0(String pathname,int row,int col){
        super(pathname,row,col);
    }
}
