package Core;

public class Mode2 extends threeMatch{
    public Mode2(int row,int col){
        super(row,col);
        int n=(int)Math.sqrt(row*col)/3;
        while(n!=0){
            int x=random.nextInt(row/2)+1,y=random.nextInt(col);
            if(chars[x][y]!='-'){
                chars[x][y]='-';
                n--;
            }
        }
    }
    public Mode2(String pathname,int row,int col){
        super(pathname,row,col);
    }
    public void countDropNumber(){
        for (int j = 0; j < col; j++) {
            for (int i = row-2; i >=0; i--) {
                if(chars[i+1][j]=='0'){
                    drop[i][j]=drop[i+1][j]+1;
                }else{
                    drop[i][j]=drop[i+1][j];
                }
                if(chars[i][j]=='-')drop[i][j]=0;
            }
        }
    }
}
